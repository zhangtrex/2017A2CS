# A2project2
## by Rex and Kevin Yang
## 1. previous project
### we created a Black Jack game, it has several functions:
### (1) basic algorithm to determine win/loss/draw with adjustable bet
### (2) a dealer to play with
### (3) a graphic user interface with self-made cards and board

### I programed 2 classes that can be applied on other card games:
### cardset and card

## 2. our plans
name | difficulty | graphic | playability | quality | comments 
--- | --- | --- | --- | --- | ---
Black Jack | 3 | 5 | 4 | 2 | add animations and 'abilities'
Texas poker | 5 | 3 | 5 | 3.5 | new casino game
Roulette | 4 | 4 | 4 | 3.5 | new casino game
other game | ? | ? | ? | ? | choose from the choices from A2project1

## 3. Final Choice:
### Roulette
### wheel : radius 25cm  15 degrees
### ball : radius 1.05cm  4.85g






