# winter project v1.0
## Rex Zhang & Kevin Yang
###1.
### A few plans we come up with:

Plan Number | Plan Name | difficulty(1-5) | choices
--- | --- | --- | ---
Plan 1 | volume control (Pinball) | 2 | x
Plan 2 | tower of Hanois | 1-2 | x
Plan 3 | the dancing line | 4-5 | x
Plan 4 | casino (black jack/taxes/tigermachine/lunpandu) | 3-4 | v
Plan 5 | The dancing flower | unknown | x

### 2.
### Our decision:
#### Plan 4
#### casino Game
#### we will first design 'Black Jack' in the holiday

### 3.
### Finished A Black Jack Game

### 4.
### Functions
#### a dealer and a player
#### graphic representation of Cards and Boards
#### you can win money

### 3.
### Codes
### classes and functions
```python

class Card():

    def __init__():

    def __repr__():

    def __str__():

    def hashfunction():

class CardSet():

    def __init__():

    def __repr__():

    def draw(): # add a card in the card set

    def count(): # count the sum of the cards (in BlackJack)

    def checkblackjack():

def DeleteElement(List,Index):

def InitializeCardDeck(): # initialize and shuffle the card deck

def InitializeCardDeckImage(): # return a dictionary with all images of cards

```

### P.S.
### Instruction of Packaging the Program
#### 1.Download and Install PyInstaller
#### 2.Find the location of PyInstaller.exe
#### 3.Use cmd, locate the file, 


###### if someone wants to access to Kevin's repository:
###### https://github.com/KevinYoung23
